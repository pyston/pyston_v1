print "Hello World from inside ziped script"
